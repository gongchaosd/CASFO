 %Sineӳ��
 function [x] = SineMap(Max_iter)
 x(1)=rand; %��ʼ��
for i=1:Max_iter-1
     x(i+1) = sin(2/x(i));
end
 end