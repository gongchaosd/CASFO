
function [ bestX, fMin,fitcurve] = ISFO( fobj, T, Max_iter, dim,lb,ub)
% Display help
rPercent=0.2;
hPercent=0.6;
mPercent=0.1;
G=10;

if nargin < 1
    fobj = @Sphere;
    T = 1000;  
    Max_iter = 100;  
    dim = 20;  
    G = 10;       
    rPercent = 0.15; 
    hPercent = 0.7;  
    mPercent = 0.5;                  
end

rNum = round( Max_iter * rPercent );    % The population size of roosters
hNum = round( Max_iter * hPercent );    % The population size of hens
cNum = Max_iter - rNum - hNum;          % The population size of chicks
mNum = round( hNum * mPercent );   % The population size of mother hens


for i = 1 : Max_iter
    x( i, : ) = lb + (ub - lb) .* rand( 1, dim ); 
    fit( i ) = fobj( x( i, : ) ); 
end
pFit = fit; % The individual's best fitness value
pX = x;     % The individual's best position corresponding to the pFit

[ fMin, bestIndex ] = min( fit );        % fMin denotes the global optimum
% bestX denotes the position corresponding to fMin
bestX = x( bestIndex, : );   


 
for t = 1 : T
    
    % This parameter is to describe how closely the chicks would follow 
    % their mother to forage for food. In fact, there exist cNum chicks, 
    % thus only cNum values of FL would be used. 
    FL = rand( Max_iter, 1 ) .* 0.4 + 0.5;  
    
    % The chicken swarm'status about hierarchal order, dominance  
    % relationship, mother-child relationship, the roosters, hens and the 
    % chicks in a group will remain stable during a period of time. These  
    % statuses can be updated every several (G) time steps.The parameter G 
    % is used to simulate the situation that the chicken swarm have been  
    % changed, including some chickens have died, or the chicks have grown 
    % up and became roosters or hens, some mother hens have hatched new
    % offspring (chicks) and so on.
   
   if mod( t, G ) == 1 || t == 1   
                
        [ ans, sortIndex ] = sort( pFit );   
        % How the chicken swarm can be divided into groups and the identity
        % of the chickens (roosters, hens and chicks) can be determined all 
        % depend on the fitness values of the chickens themselves. Hence we 
        % use sortIndex(i) to describe the chicken, not the index i itself.
        
        motherLib = randperm( hNum, mNum ) + rNum;   
        % Randomly select mNum hens which would be the mother hens.
        % We assume that all roosters are stronger than the hens, likewise, 
        % hens are stronger than the chicks.In CSO, the strong is reflected
        % by the good fitness value. Here, the optimization problems is 
        % minimal ones, thus the more strong ones correspond to the ones  
        % with lower fitness values.
  
        % Given the fact the 1 : rNum chickens' fitness values maybe not
        % the best rNum ones. Thus we use sortIndex( 1 : rNum ) to describe
        % the roosters. In turn, sortIndex( (rNum + 1) :(rNum + 1 + hNum ))
        % to describle the mother hens, .....chicks.

        % Here motherLib include all the mother hens. 
      
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Randomly select each hen's mate, rooster. Hence we can determine
        % which group each hen inhabits using "mate".Each rooster stands
        % for a group.For simplicity, we assume that there exist only one
        % rooster and at least one hen in each group.
        mate = randpermF( rNum, hNum );
        
        % Randomly select cNum chicks' mother hens
        mother = motherLib( randi( mNum, cNum, 1 ) );  
   end
    
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
   for i = 1 : rNum                % Update the rNum roosters' values.
        
        % randomly select another rooster different from the i (th) one.
        anotherRooster = randiTabu( 1, rNum, i, 1 );  
        if( pFit( sortIndex( i ) ) <= pFit( sortIndex( anotherRooster ) ) )
            tempSigma = 1;
        else
            tempSigma = exp( ( pFit( sortIndex( anotherRooster ) ) - ...
                pFit( sortIndex( i ) ) ) / ( abs( pFit( sortIndex(i) ) )...
                + realmin ) );
        end
        
        x( sortIndex( i ), : ) = pX( sortIndex( i ), : ) .* ( 1 + ...
            tempSigma .* randn( 1, dim ) );
        x( sortIndex( i ), : ) = Bounds( x( sortIndex( i ), : ), lb, ub );
        fit( sortIndex( i ) ) = fobj( x( sortIndex( i ), : ) );
    end
    
    for i = ( rNum + 1 ) : ( rNum + hNum )  % Update the hNum hens' values.
        
        other = randiTabu( 1,  i,  mate( i - rNum ), 1 );  
       
        
        c1 = exp( ( pFit( sortIndex( i ) ) - pFit( sortIndex( mate( i - ...
            rNum ) ) ) )/ ( abs( pFit( sortIndex(i) ) ) + realmin ) );
            
        c2 = exp( ( -pFit( sortIndex( i ) ) + pFit( sortIndex( other ) )));

        x( sortIndex( i ), : ) = pX( sortIndex( i ), : ) + ( pX(...
            sortIndex( mate( i - rNum ) ), : )- pX( sortIndex( i ), : ) )...
             .* c1 .* rand( 1, dim ) + ( pX( sortIndex( other ), : ) - ...
             pX( sortIndex( i ), : ) ) .* c2 .* rand( 1, dim ); 
        x( sortIndex( i ), : ) = Bounds( x( sortIndex( i ), : ), lb, ub );
        fit( sortIndex( i ) ) = fobj( x( sortIndex( i ), : ) );
    end
    
    for i = ( rNum + hNum + 1 ) : Max_iter    % Update the cNum chicks' values.
        x( sortIndex( i ), : ) = pX( sortIndex( i ), : ) + ( pX( ...
            sortIndex( mother( i - rNum - hNum ) ), : ) - ...
            pX( sortIndex( i ), : ) ) .* FL( i );
        x( sortIndex( i ), : ) = Bounds( x( sortIndex( i ), : ), lb, ub );
        fit( sortIndex( i ) ) = fobj( x( sortIndex( i ), : ) );
    end
    
 
    for i = 1 : Max_iter 
        if ( fit( i ) < pFit( i ) )
            pFit( i ) = fit( i );
            pX( i, : ) = x( i, : );
        end
        
        if( pFit( i ) < fMin )
            fMin = pFit( i );
            bestX = pX( i, : );
        end
    end
    fitcurve(t) = fMin;
end

function y = Sphere( x )
y = sum( x .^ 2 );


function s = Bounds( s, Lb, Ub)

  temp = s;
  I = temp < Lb;
  temp(I) = Lb(I);
  
  % Apply the upper bound vector 
  J = temp > Ub;
  temp(J) = Ub(J);
  % Update this new move 
  s = temp;

function value = randiTabu( min, max, tabu, dim )
value = ones( dim, 1 ) .* max .* 2;
num = 1;
while ( num <= dim )
    temp = randi( [min, max], 1, 1 );
    if( length( find( value ~= temp ) ) == dim && temp ~= tabu )
        value( num ) = temp;
        num = num + 1;
    end
end

%--------------------------------------------------------------------------
function result = randpermF( range, dim )

temp = randperm( range, range );
temp2 = randi( range, dim, 1 );
index = randperm( dim, ( dim - range ) );
result = [ temp, temp2( index )' ];