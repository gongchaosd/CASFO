%_________________________________________________________________________%
% ��Ľ��������Ż��㷨�Ա� %
%_________________________________________________________________________%


clear all 
clc
% rng('default');
SearchAgents_no=30; % Number of search agents ��Ⱥ����

Function_name='F14'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper) �趨��Ӧ�Ⱥ���

Max_iteration=1000; % Maximum numbef of iterations �趨����������

% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);  %�趨�߽��Լ��Ż�����
%�Ľ��������Ż��㷨
 [Best_pos,Best_score,CASFO_curve0]= MASFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
 %����1
 [Best_pos1,Best_score1,MSFO_curve1]=MSFO( fobj,Max_iteration, SearchAgents_no, dim,lb*ones(1,dim),ub*ones(1,dim)); %��ʼ�Ż�
%����2
 [Best_pos2,Best_score2,ISFO_curve2]=ISFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
 
 [Best_pos1,Best_score3,SFO_curve3]=SFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
% figure('Position',[269   240   660   290])
%Draw search space
% subplot(1,2,1);
% figure(1)
% func_plot(Function_name);
% title('Parameter space')
% xlabel('x_1');
% ylabel('x_2');
% zlabel([Function_name,'( x_1 , x_2 )'])


figure()
L=2;
a=semilogy(CASFO_curve0,'-s','Color','r','linewidth',L);

a.MarkerIndices = 1:100:length(CASFO_curve0);
hold on
b=semilogy(MSFO_curve1,'-*','Color','k','linewidth',L);
b.MarkerIndices = 1:100:length(MSFO_curve1);
c=semilogy(ISFO_curve2,'-x','Color',[0.2,1,0.9],'linewidth',L);
c.MarkerIndices = 1:100:length(ISFO_curve2);
d=semilogy(SFO_curve3,'-o','Color','b','linewidth',L);
d.MarkerIndices = 1:100:length(SFO_curve3);

title('F1 itertively converges the semilog curve','FontSize',12,'FontWeight','bold')

xlabel('Iteration','FontSize',12,'FontWeight','bold');
ylabel('Average Fitness Value','FontSize',12,'FontWeight','bold');
set(gca, 'FontSize', 12,'FontWeight','bold')
axis tight

legend('CASFO','MSFO','ISFO','SFO')
set(legend,'Location','NorthEastOutside');

