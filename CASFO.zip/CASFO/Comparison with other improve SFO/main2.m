clear all 
clc

Function_name='F21'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper) �趨��Ӧ�Ⱥ���

Max_iteration=1000; % Maximum numbef of iterations �趨����������
SearchAgents_no = 30 ;%population
% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);  %�趨�߽��Լ��Ż����� 
% count1=zeros(1,30);
count2=zeros(1,30);
count3=zeros(1,30);
% 
% for i=1:30
% % %�Ľ��������Ż��㷨
% [Best_pos,Best_score1,CASFO_curve1]= CASFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%     count1(i)=Best_score1;
% end


for i=1:30
 %����1
 [Best_pos1,Best_score2,MSFO_curve2]=MSFO( fobj,Max_iteration, SearchAgents_no, dim,lb*ones(1,dim),ub*ones(1,dim)); %��ʼ�Ż�
    count2(i)=Best_score2;
end

for i=1:30
 %����2
 [Best_pos2,Best_score3,ISFO_curve3]=ISFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
    count3(i)=Best_score3;

end

% A=sort(count1);
B=sort(count2);
C=sort(count3);

% CASFOMEAN = mean(A);
% CASFOSTD=std(A);
MSFOMEAN = mean(B);
MSFOSTD=std(B);
ISFOMEAN = mean(C);
ISFOSTD=std(C);

% % figure()
% %boxplot([count1',count2',count3',count4',count5',count6'],'Notch','on','Labels',{'ISFO','SFO','PSO','WOA','BOA','GWO'})
% %boxplot([count1',count2',count3',count4',count5',count6',count7',count8'],'Notch','marker','Labels',{'MASFO','SFO','PSO','GA','SA','WOA','BOA','GWO'})
% % boxplot([count0',count1',count2',count3',count4',count5',count6',count7'],'Labels',{'MASFO','SFO','PSO','GA','SA','WOA','BOA','GWO'})
% xlabel('Algorithms','FontSize',12,'FontWeight','bold')
% % ylabel('Fitness Value','FontSize',12,'FontWeight','bold')
% % title('F20 function 30 times to test the optimal value boxplot','FontSize',14,'FontWeight','bold')
% % set(gca, 'FontSize', 12,'FontWeight','bold')
