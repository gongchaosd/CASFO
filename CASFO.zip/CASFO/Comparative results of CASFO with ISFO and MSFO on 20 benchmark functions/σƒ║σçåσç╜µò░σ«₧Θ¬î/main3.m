%_________________________________________________________________________%
% �Ľ��������Ż��㷨             %
%_________________________________________________________________________%


clear all 
clc
% rng('default');
SearchAgents_no=30; % Number of search agents ��Ⱥ����

Function_name='F1'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper) �趨��Ӧ�Ⱥ���

Max_iteration=1000; % Maximum numbef of iterations �趨����������

% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);  %�趨�߽��Լ��Ż�����
%�Ľ��������Ż��㷨
[Best_pos,Best_score,ISFO_curve0]=ISFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����Ż��㷨
[Best_pos1,Best_score1,SFO_curve1]=SFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%����Ⱥ�Ż��㷨
[Best_pos2,Best_score2,PSO_curve2]=PSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����Ż��㷨
[Best_pos3,Best_score3,WOA_curve3]=WOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����Ż��㷨
 [Best_pos4,Best_score4,BOA_curve4]=BOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����㷨
[Best_pos6,Best_score6,GWO_curve5]=GWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
% figure('Position',[269   240   660   290])
%Draw search space
% subplot(1,2,1);
% figure(1)
% func_plot(Function_name);
% title('Parameter space')
% xlabel('x_1');
% ylabel('x_2');
% zlabel([Function_name,'( x_1 , x_2 )'])

%Draw objective space
figure()
% a=semilogy(ISFO_curve0,'-d','Color','r','linewidth',1.5);
a=plot(ISFO_curve0,'-d','Color','r','linewidth',1);
a.MarkerIndices = 1:30:length(ISFO_curve0);
hold on
% b=semilogy(SFO_curve1,'-s','Color','m','linewidth',1.5);
b=plot(SFO_curve1,'-s','Color','m','linewidth',1);
b.MarkerIndices = 1:30:length(SFO_curve1);
% c=semilogy(PSO_curve2,'-x','Color','k','linewidth',1.5);
c=plot(PSO_curve2,'-x','Color','k','linewidth',1);
c.MarkerIndices = 1:30:length(PSO_curve2);
% d=semilogy(WOA_curve3,'-*','Color','b','linewidth',1.5);
d=plot(WOA_curve3,'-*','Color','b','linewidth',1);
d.MarkerIndices = 1:30:length(WOA_curve3); 
% e=semilogy(BOA_curve4,'-o','Color','c','linewidth',1.5);
e=plot(BOA_curve4,'-o','Color','c','linewidth',1);
e.MarkerIndices = 1:30:length(BOA_curve4); 
% f=semilogy(GWO_curve5,'-p','Color','y','linewidth',1);
f=plot(GWO_curve5,'-p','Color','y','linewidth',1);
f.MarkerIndices = 1:30:length(GWO_curve5); 
title('F20')
xlabel('Iteration');
ylabel('Average Fitness Value');

axis tight

legend('ISFO','SFO','PSO','WOA','BOA','GWO')

% display(['The best solution obtained by SFO is : ', num2str(Best_pos)]);
% display(['The best optimal value of the objective funciton found by SSA is : ', num2str(Best_score)]);
% 
% 
% display(['The best solution obtained by SFONew is : ', num2str(Best_pos1)]);
% display(['The best optimal value of the objective funciton found by SSANew is : ', num2str(Best_score1)]);
%         
% 
% 
% 
