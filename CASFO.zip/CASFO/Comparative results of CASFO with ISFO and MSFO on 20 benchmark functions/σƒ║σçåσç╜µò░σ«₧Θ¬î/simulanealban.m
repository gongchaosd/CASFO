clear all 
clc
% rng('default');
SearchAgents_no=30; % Number of search agents 种群数量

Function_name='F2'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper) 设定适应度函数

Max_iteration=1000; % Maximum numbef of iterations 设定最大迭代次数

% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);  %设定边界以及优化函数
%改进的旗鱼优化算法
 [Best_pos,Best_score,MASFO_curve0]=CSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %开始优化
