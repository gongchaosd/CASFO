

Function_name='F18'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper) 设定适应度函数

Max_iteration=1000; % Maximum numbef of iterations 设定最大迭代次数

%画图

figure(1)
func_plot(Function_name);
title('F18 Parameter space')
xlabel('x_1');
ylabel('x_2');
zlabel([Function_name,'( x_1 , x_2 )'])
