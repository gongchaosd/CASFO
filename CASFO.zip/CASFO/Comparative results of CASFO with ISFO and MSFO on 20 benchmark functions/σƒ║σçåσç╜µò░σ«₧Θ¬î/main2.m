clear all 
clc

Function_name='F21'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper) �趨��Ӧ�Ⱥ���

Max_iteration=1000; % Maximum numbef of iterations �趨����������
SearchAgents_no = 30 ;%population
% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);  %�趨�߽��Լ��Ż����� 
count0=zeros(1,30);
% count1=zeros(1,30);
% count2=zeros(1,30);
count3=zeros(1,30);
count4=zeros(1,30);
% count5=zeros(1,30);
% count6=zeros(1,30);
% count7=zeros(1,30);
tic
for i=1:30
% %�Ľ��������Ż��㷨
 [Best_pos,Best_score0,MASFO_curve0]=MASFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����Ż��㷨
%  [Best_pos1,Best_score1,SFO_curve1]=SFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
% %����Ⱥ�Ż��㷨
%  [Best_pos2,Best_score2,PSO_curve2]=PSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
 %�Ŵ��㷨
 [Best_pos3,Best_score3,GA_curve3]=GA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
 %ģ���˻��㷨
 [Best_pos4,Best_score4,SA_curve4]=SA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
% %�����Ż��㷨
% [Best_pos5,Best_score5,WOA_curve5]=WOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
% %�����Ż��㷨
%  [Best_pos6,Best_score6,BOA_curve6]=BOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
% %�����㷨
%  [Best_pos7,Best_score7,GWO_curve7]=GWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
% 
% 

    count0(i)=Best_score0;
%     count1(i)=Best_score1;
%     count2(i)=Best_score2;
    count3(i)=Best_score3;
    count4(i)=Best_score4;
%     count5(i)=Best_score5;
%     count6(i)=Best_score6;
%     count7(i)=Best_score7;
end
toc
% A=sort(count2);
% B=sort(count3);
% GABEST = A(1);
% GAWORST = A(end);
% SABEST = B(1);
% SAWORST = B(end);
% GAMEAN = mean(A);
% SAMEAN = mean(B);
% GASTD=std(A);
% SASTD=std(B);
[p1,h] = ranksum(count0,count3,0.05);
[p2,h] = ranksum(count0,count4,0.05);
% figure()
%boxplot([count1',count2',count3',count4',count5',count6'],'Notch','on','Labels',{'ISFO','SFO','PSO','WOA','BOA','GWO'})
%boxplot([count1',count2',count3',count4',count5',count6',count7',count8'],'Notch','marker','Labels',{'MASFO','SFO','PSO','GA','SA','WOA','BOA','GWO'})
% boxplot([count0',count1',count2',count3',count4',count5',count6',count7'],'Labels',{'MASFO','SFO','PSO','GA','SA','WOA','BOA','GWO'})
xlabel('Algorithms','FontSize',12,'FontWeight','bold')
% ylabel('Fitness Value','FontSize',12,'FontWeight','bold')
% title('F20 function 30 times to test the optimal value boxplot','FontSize',14,'FontWeight','bold')
% set(gca, 'FontSize', 12,'FontWeight','bold')
