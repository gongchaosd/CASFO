%_________________________________________________________________________%
% �Ľ��������Ż��㷨 %
%_________________________________________________________________________%


clear all 
clc
% rng('default');
SearchAgents_no=30; % Number of search agents ��Ⱥ����

Function_name='F9'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper) �趨��Ӧ�Ⱥ���

Max_iteration=1000; % Maximum numbef of iterations �趨����������
% for i = 1:5
% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);  %�趨�߽��Լ��Ż�����
%�Ľ��������Ż��㷨
 [Best_pos,Best_score,MASFO_curve0]= ISFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����Ż��㷨
 [Best_pos1,Best_score1,SFO_curve1]=SFO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%����Ⱥ�Ż��㷨
 [Best_pos2,Best_score2,PSO_curve2]=PSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
 [Best_pos3,Best_score3,GA_curve3]=GA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
 [Best_pos4,Best_score4,SA_curve4]=SA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����Ż��㷨
[Best_pos5,Best_score5,WOA_curve5]=WOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����Ż��㷨
 [Best_pos6,Best_score6,BOA_curve6]=BOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); %��ʼ�Ż�
%�����㷨
 [Best_pos7,Best_score7,GWO_curve7]=GWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
figure('Position',[269   240   660   290])
% Draw search space
subplot(1,2,1);
figure(1)
func_plot(Function_name);
title('Parameter space')
xlabel('x_1');
ylabel('x_2');
zlabel([Function_name,'( x_1 , x_2 )'])


figure()
L=2;
a=semilogy(MASFO_curve0,'-s','Color','r','linewidth',L);

a.MarkerIndices = 1:100:length(MASFO_curve0);
hold on
b=semilogy(SFO_curve1,'-o','Color','b','linewidth',L);
b.MarkerIndices = 1:100:length(SFO_curve1);
c=semilogy(PSO_curve2,'-x','Color','k','linewidth',L);
c.MarkerIndices = 1:100:length(PSO_curve2);
d=semilogy(GA_curve3,'->','Color',[0.48 0 0.43],'linewidth',L);
d.MarkerIndices = 1:100:length(SA_curve4);
g=semilogy(SA_curve4,'-<','Color',[0.1 0.5 0.23],'linewidth',L);
g.MarkerIndices = 1:100:length(GA_curve3);

e=semilogy(WOA_curve5,'-^','Color','m','linewidth',L);
e.MarkerIndices = 1:100:length(WOA_curve5); 
f=semilogy(BOA_curve6,'-+','Color','c','linewidth',L);
f.MarkerIndices = 1:100:length(BOA_curve6); 
g=semilogy(GWO_curve7,'-p','Color',[0.2,0.35,0.5],'linewidth',L);
g.MarkerIndices = 1:100:length(GWO_curve7); 

title('F20 itertively converges the semilog curve','FontSize',12,'FontWeight','bold')

xlabel('Iteration','FontSize',12,'FontWeight','bold');
ylabel('Average Fitness Value','FontSize',12,'FontWeight','bold');
set(gca, 'FontSize', 12,'FontWeight','bold')
axis tight

legend('CASFO','SFO','PSO','GA','SA','WOA','BOA','GWO')
set(legend,'Location','NorthEastOutside');
% end
