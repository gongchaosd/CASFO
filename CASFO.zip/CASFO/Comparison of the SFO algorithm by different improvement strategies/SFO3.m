%_________________________________________________________________________%
%混合的SFO  Sailfish optimizer算法             %
%_________________________________________________________________________%
function [Best_pos,Best_score,curve]=SFO3(pop,Max_iter,lb,ub,dim,fobj)
A = 4;
e = 0.001;
SFpercent = 0.3;
SFNumber = round(pop*SFpercent);%四舍五入取整
SNumber = pop - SFNumber;
p = 0.5;%t分布变异概率
if(max(size(ub)) == 1)
   ub = ub.*ones(1,dim);
   lb = lb.*ones(1,dim);  
end
%种群初始化
XSF0 = initialization(SFNumber,dim,ub,lb);%sailfish 初始化
XS0 = initializationNew(SNumber,dim,ub,lb);%sardines 初始化
XSF = XSF0;
XS = XS0;
%计算初始适应度值
fitnessSF = zeros(1,SFNumber);
fitnessS = zeros(1,SNumber);
for i = 1:size(XSF,1)
   fitnessSF(i) =  fobj(XSF(i,:));
end
for i = 1:size(XS,1)
   fitnessS(i) = fobj(XS(i,:));
end
 [fitnessSF, indexSF]= sort(fitnessSF);%排序
 Xelite = XSF(indexSF(1),:);%sailfish 最优值
 [fitnessS, indexS]= sort(fitnessS);%排序
 Xinjured = XS(indexS(1),:);%sardines 最优值
 %根据适应度排序
 XSF = XSF(indexSF,:);
 XS = XS(indexS,:);
 %记录全局最优位置
 if(fitnessSF(1)<fitnessS(1))
    GBestX = XSF(1,:);
    GBestF = fitnessSF(1);
 else
     GBestX = XS(1,:);
     GBestF = fitnessS(1);
 end
curve=zeros(1,Max_iter);
XSFnew = XSF;
XSnew = XS;
for t = 1: Max_iter
   %% 更新XSF
    PD = 1 - (size(XSF,1)/(size(XSF,1) + size(XS,1)));
    lamda = 2*rand()*PD - PD;
    for i = 1:size(XSFnew,1)
       XSFnew1(i,:) = Xelite - lamda.*(rand().*((Xelite + Xinjured)./2)-XSF(i,:));
       %改进点：贪心策略
       if fobj(XSFnew1(i,:))<fobj(XSF(i,:))
           XSFnew(i,:) = XSFnew1(i,:);
       end         
    end
     %% 更新XS
    AP = A*(1-(2*t*e));
         for i = 1:size(XSnew,1)
          %改进点：贪心策略
           XSnew2(i,:) = rand().*(Xelite - XS(i,:) + AP);
            if fobj(XSnew2(i,:))<fobj(XS(i,:))
             XSnew(i,:) = XSnew2(i,:);
            end      
         end
     %边界控制
   for j = 1:size(XSFnew,1)
       for a = 1: dim
           if(XSFnew(j,a)>ub)
               XSFnew(j,a) =ub(a);
           end
           if(XSFnew(j,a)<lb)
               XSFnew(j,a) =lb(a);
           end
       end
   end 
    for j = 1:size(XSnew,1)
       for a = 1: dim
           if(XSnew(j,a)>ub)
               XSnew(j,a) =ub(a);
           end
           if(XSnew(j,a)<lb)
               XSnew(j,a) =lb(a);
           end
       end
    end 
    %计算当前适应度值
    for i = 1:size(XSF,1)
     fitnessSF(i) =  fobj(XSFnew(i,:));
    end
    for i = 1:size(XS,1)
     fitnessS(i) = fobj(XSnew(i,:));
    end
    %更据适应度替换
%     deleteIndex = zeros(1,size(XSnew,1));%用来记录需要移除的sardines的位置
    for i = 1:min(size(XSFnew,1),size(XSnew,1))
        if(fitnessS(i)<fitnessSF(i))
           XSFnew(i,:) = XSnew(i,:);
%            deleteIndex(i) = 1;
        end
    end
    % 去除这一步更新移除的沙丁鱼位置,利用其他位置代替
%     for i = 1:size(XSnew,1)
%        if(deleteIndex(i) == 1)
%            XSnew(i,:) = rand(1,dim).*(ub-lb)+lb;
%        end
%     end
%     for i = 1:size(XS,1)
%      fitnessS(i) = fobj(XSnew(i,:));
%     end
    %改进点：自适应t分布变异
%     for j = 1:SNumber
%         if rand < p
%            Temp = XSnew(j,:) + XSnew(j,:)*trnd(t); %基于迭代次数的t分布变异
%            %边界处理
%            Temp(Temp>ub) = ub(Temp>ub);
%            Temp(Temp<lb) = lb(Temp<lb);
%            fitvalue = fobj(Temp);
%            if(fitvalue <fitnessS(j))
%                XSnew(j,:) = Temp;
%                fitnessS(j) = fitvalue;
%            end
%         end    
%     end
    XSF = XSFnew;
    XS  = XSnew;
  %% 遗传自然选择
 [fitnessSF, indexSF]= sort(fitnessSF);%排序
 Xelite = XSF(indexSF(1),:);%sailfish 最优值
  exIndex = round((SFNumber-1)/2);
 XSF(indexSF((SFNumber-exIndex+1):SFNumber)) = XSF(sort(1:exIndex));
 [fitnessS, indexS]= sort(fitnessS);%排序
 Xinjured = XS(indexS(1),:);%sardines 最优值
 exIndex = round((SNumber-1)/2);
 XS(indexS((SNumber-exIndex+1):SNumber)) = XS(sort(1:exIndex));
 
 %根据适应度排序
 XSF = XSF(indexSF,:);
 XS = XS(indexS,:);

 %记录全局最优位置
 if(fitnessSF(1)<fitnessS(1))
    LocalGBestX = XSF(1,:);
    LocalGBestF = fitnessSF(1);
 else
     LocalGBestX = XS(1,:);
     LocalGBestF = fitnessS(1);
 end
 if(LocalGBestF<GBestF)
     GBestF = LocalGBestF;
     GBestX = LocalGBestX;
 end
 
   curve(t) = GBestF;
end
Best_pos = GBestX;
Best_score = curve(end);
end
